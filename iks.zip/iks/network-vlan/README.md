# Cloud Z CP Single Zone Cluster Provisioning

https://console.bluemix.net/docs/containers/cs_clusters_planning.html#single_zone